</h1> 
<p align="center"> 𝖄𝕰𝕾𝕾𝕰𝕽 𝕸𝕯

<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=100&size=20&duration=9000&pause=200&random=false&width=535&lines=+MY+NAME+ IS+YESSER+MD+BOT+CREATED+BY+YESSER+tech+SON+Fork+Me+Please" alt="Typing SVG" /></a>
 </p>
 
 <a href="https://chat.whatsapp.com/DFmm1OBboewBk9kEDBrfNv">
 <img alt="𝕐𝔼𝕊𝕊𝔼ℝ 𝕄𝔻" height="300" src="https://files.catbox.moe/eou4n8.jpeg".

</h1> 
<p align="center">ɪ ɪɴᴛʀᴏᴅᴜᴄᴇ <b>𝕃
YESSER MD</b>, simple powerful bot </p>

</p>
  <p align="center">
<a href="https://github.com/yassin994?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/yassin994?label=Followers&style=social"></a>
<a href="https://github.com/yassin994/YESSER-MD/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/yassin994/YESSER-MD?&style=social"></a>
<a href="https://github.com/yassin994/YESSER-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/yassin994/YESSER-MD?style=social"></a>
<a href="https://github.com/yassin994/YESSER-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/yassin994/YESSER-MD?label=Watching&style=social"></a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{yassin994}/count.svg" alt="YESSER-MD :: Visitor's Count"/></p>

</a>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&black=true&scan=true" alt="Widget with the current Spotify song"  />
</div>

---

<p align="center">
  <a href="https://github.com/yassin994/yesser_md"><b>𝕐𝔼𝕊𝕊𝔼ℝ 𝕄𝔻</b></a> 𝙎𝙪𝙥𝙥𝙤𝙧𝙩 𝘿𝙚𝙥𝙡𝙤𝙮 𝙊𝙣...
</p>

<p align="center">
  <a href="https://youtu.be/vgQlWzsmMcI?si=gYzfuFfVSJedpuhh"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>







## HOW TO DEPLOY YESSER MD 🤠 


## 1. FIRST STEP 
FORK this repo YESSER-MD


<a href="https://github.com/yassin994/YESSER-MD/fork"><img title="Tap Here Open session site" src="https://img.shields.io/badge/𝔽𝕆ℝ𝕂 𝕋ℍ𝕀𝕊 ℝ𝔼ℙ𝕆-h?color=black&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

sᴛᴀʀ 🌟 ᴍʏ ʀᴇᴘᴏ ɪғ ʏᴏᴜ ʟɪᴋᴇ ᴛʜɪs ʙᴏᴛ ®️

## 2.SECOND STEP
 *CONNECT BY PAIRING CODE THROUGH BOTH STYLE*


##*YESSER MD NORMAL BOT*##

   ༆𝕊𝔼𝕊𝕊𝕀𝕆ℕ 𝕊𝕀𝕋𝔼༆
𝐟𝐨𝐫 𝐧𝐨𝐫𝐦𝐚𝐥 𝐛𝐨𝐭👇 𝐩𝐚𝐢𝐫 𝐬𝐞𝐬𝐬𝐢𝐨𝐧 𝐢𝐝
 

<a href="https://yesser.onrender.com"><img title="Tap Here Open session Site" src="https://img.shields.io/badge/ℚℝ ℂ𝕆𝔻𝔼-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>


 
<a href="https://yesser.onrender.com"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/normal bot pair-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

##*YESSER MD BOTTOM BOT*##


  𝐟𝐨𝐫 𝐛𝐨𝐭𝐭𝐨𝐦 𝐛𝐨𝐭 👇 𝐩𝐚𝐢𝐫 𝐬𝐞𝐬𝐬𝐢𝐨𝐧 𝐢𝐝
 

    
<a href='https://yesser-scanner-8309ae116f64.herokuapp.com/' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Sbottom pair-900000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=blue'/></a>


    
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a> 







## 3. LAST STEP HERE WE GO 🤠
**1. ɪғ ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏɴ ʜᴇʀᴏᴋᴜ**
💯 ### 🎁 DEPLOY ON HEROUK ##
<a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/ℂℝ𝔼𝔸𝕋𝔼%20𝔸ℂℂ𝕆𝕌ℕ𝕋%20ℕ𝕆𝕎-purple?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>

**2. ɪғ ʏᴏᴜ ʜᴀᴠᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏɴ ʜᴇʀᴏᴋᴜ**       
<br>
<a href="https://dashboard.heroku.com/new?template=https://github.com/Yassin994/YESSER-1/tree/main">
 <img src="https://img.shields.io/badge/𝔻𝔼ℙ𝕃𝕆𝕐%20𝕋𝕆%20ℍ𝔼ℝ𝕆𝕂𝕌-purple?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>




#### DEPLOY ON RENDER 
**1. If You Don't Have An Account On Render**
- <a href="https://dashboard.render.com/register"><img src="https://img.shields.io/badge/CREATE AN ACCOUNT NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

**2. If You Have an account on Render**
- <a href="https://render.com"><img title="Deploy Now" src="https://img.shields.io/badge/DEPLOY NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

**.Create an account on UPTIME TO MAKE YOUR RENDER BOT STABLE**
- <a href="https://uptimerobot.com"><img title="Deploy Now" src="https://img.shields.io/badge/CREATE NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>






#### DEPLOY TO PANEL 

1. If You don't have a account on panel Create a account.
    <br>
<a href='https://bot-hosting.net/?aff=1086839354611212288' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=Pink&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>


2. Now Deploy
    <br>
<a href='https://bot-hosting.net/?aff=1086839354611212288' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>



*guys that main zip is for panel deployers but isn't finished yet so just cool soon we will fix it keep turned...* 💔



#### <a href="https://github.com/yassin994/YESSER-MD/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/DOWNLOAD%20FILE-HERE-red" alt="Rainhost Files" width="150"></a>






## DO YOU NEED SUPPORT? 🤠yes im here to help you 24hrs. 

🎁 owner on wastapp 🤙
<a href="https://wa.me/255621995482?text=Hi+YESSERTECH+I+Need+Help" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="255621995482" height="60" width="70" /></a>


𝙮𝙚𝙨𝙨𝙚𝙧𝙩𝙚𝙘𝙝 𝙨𝙪𝙥𝙥𝙤𝙧𝙩 𝙜𝙧𝙤𝙪𝙥🎤
<a
href="https://chat.whatsapp.com/DFmm1OBboewBk9kEDBrfNv" target="blank"><img
 align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="yessertech" height="60" width="70" /></a>


😭 FOLLOW MY YOUTUBE CHANNEL
<a href="https://www.youtube.com/@Yesserboy92" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="yessertech" height="60" width="70" /></a>


## License

The WhatsApp Bot YESSER MD is released under the [MIT License](https://opensource.org/licenses/MIT).

 <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•Role+number-one; don't-trust+any one+🖐️🤠;DEVELOPED+BY+YESSER+TECH;RELEASED+DATE+22%2F6%2F2024." alt="Typing SVG" /></a>


🌟 *thanks for using YESSER🤠_MD*

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&random=false&width=435&lines=THIS+IS+YESSER- MD+MADE+IN+TANZANIA+🇹🇿♥️" alt="Typing SVG" /></a>

## 𝔻𝔼𝕍𝔼𝕃𝕆ℙ𝔼ℝ𝕊 :

- [**YESSIR TECH**](https://github.com/yassin994)
- [**BONIPHACE TECH**](http://github.com/Boniphace30)
- [**Developers YT**](https://www.youtube.com/@Yesserboy92)


★im born to win🏹. ©
     

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=700&size=33&pause=1000&color=5513F7&width=435&lines=keep+using+YESSER+MD🤠" alt="Typing SVG" /></a>





*KINGDOM*

<table>
  <tr>
    <td>YESSER</td></td>
    <td>𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑪𝒉𝒂𝒏𝒏𝒆𝒍</td>
  </tr>
  <tr>
    <td><a href="https://wa.me/255716662453?"><img src="https://i.imgur.com/5cfyybs.jpeg" width="180"</td>
    <td><a href="https://whatsapp.com/channel/0029VaiMm7d4yltT51HS1T1G"><img src="https://i.imgur.com/5cfyybs.jpeg" width="180"</td>
  </tr>
</table>

</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>







*`🎁 available services🎁
👉i creat herouk acc for 4k
👉 i deploy bots for 3k
👉i made owners bost for 25k*


## like that one 🎁herouk card🎁##
......... YESSER CARD............

🎁 *Card* 4403530005953162

💔 *Cvv* 808
❤️. *Exp* 10/27

💀 *name* yesser tech
💀 *country* Tanzania

💀. *city* Dar es salaam
................................................




 
 <a href="https://chat.whatsapp.com/DFmm1OBboewBk9kEDBrfNv">
 <img alt="𝕐𝔼𝕊𝕊𝔼ℝ 𝕄𝔻" height="200" src="https://files.catbox.moe/q7aubp.mp4".


❤️ one love .................
